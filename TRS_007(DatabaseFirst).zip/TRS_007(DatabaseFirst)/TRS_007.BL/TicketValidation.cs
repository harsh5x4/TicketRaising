﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRS_007.Exception;
using TRS_007.DAL;
using TRS_007.Entity;

namespace TRS_007.BL
{
    public class TicketValidation
    {
        public static bool ValidateEmployee(Ticket_007 tkt)
        {
            bool tktValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (tkt.Category.Trim() != "Computing")
                {
                    message.Append("Category must be \"Personal \"Computing\n");
                    tktValidated = false;
                }

                if (tkt.SubCategory.Trim() != "Desktop"
                    && tkt.SubCategory.Trim() != "Laptop"
                    && tkt.SubCategory.Trim() != "Mobile Pass"
                    && tkt.SubCategory.Trim() != "PC")
                {
                    message.Append("Please Select valid sub-category");
                    tktValidated = false;
                }

              

                if (tktValidated == false)
                    throw new Ticket_Exception(message.ToString());
            }
            catch (Ticket_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return tktValidated;
        }

        public static Employee_007 SearchEmployee(int empID)
        {
            Employee_007 emp = null;

            try
            {
                emp = Operation_007.Verify_Employee(empID);
            }
            catch (Ticket_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }


        public static int AddTicket(Ticket_007 emp)
        {
            int records = 0;

            try
            {
                if (ValidateEmployee(emp))
                {
                    records = Operation_007.AddTicket(emp);
                }
                else
                    throw new Ticket_Exception("Please provide valid information");
            }
            catch (Ticket_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        public static List<Ticket_007> GetAllTickets()
        {
            List<Ticket_007> tktList = null;

            try
            {
                tktList = Operation_007.GetAllTickets();
            }
            catch (Ticket_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return tktList;
        }








    }
}
