﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRS_007.Entity;
using TRS_007.Exception;

namespace TRS_007.DAL
{
    public class Operation_007
    {
        static Con_007 context = new Con_007();

        public static int AddTicket(Ticket_007 tkt)
        {
            int records = 0;

            try
            {
                context.Ticket_007.Add(tkt);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }





        public static Employee_007 Verify_Employee(int empID)
        {
            Employee_007 emp = null;
           
            try
            {
                emp = (from e in context.Employee_007
                       where e.Emp_Id == empID
                       select e).FirstOrDefault();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }



        public static List<Ticket_007> GetAllTickets()
        {
            List<Ticket_007> tktList = null;

            try
            {
                tktList = context.Ticket_007.ToList<Ticket_007>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return tktList;
        }





    }

}
