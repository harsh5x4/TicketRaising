﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRS_007.Exception
{
    public class Ticket_Exception : ApplicationException
    {
        public Ticket_Exception()
            : base()
        { }

        public Ticket_Exception(string message)
            : base(message)
        { }
    }
}
