﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TRS_007.BL;
using TRS_007.Entity;
using TRS_007.Exception;

namespace TRS_007.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowData();
        }

        public void ShowData()
        {
            try
            {
                dgTicket.DataContext = TicketValidation.GetAllTickets();
                //dgTicket.Items.Refresh();
            }
            catch (Ticket_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void Clear()
        {

        }

        private void btn_createTicket_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Ticket_007 tkt = new Ticket_007();
                tkt.Category = lblCatValue.Content.ToString();
                tkt.SubCategory = ((ComboBoxItem)cmbSubCat.SelectedItem).Content.ToString();
                tkt.Description = txtDesValue.Text;
                tkt.Emp_Id = Convert.ToInt32(txtEmpID.Text);


                int records = TicketValidation.AddTicket(tkt);
                //ShowData();
                if (records > 0)
                {
                    MessageBox.Show("Ticket record added successfully");
                    ShowData();
                    Clear();
                }
                else
                    throw new Ticket_Exception("Ticket record not added");
            }
            catch (Ticket_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnVerify_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtEmpID.Text);

                Employee_007 emp = TicketValidation.SearchEmployee(id);

                if (emp != null)
                {
                    lblName.Content = emp.Emp_Name;
                   
                    lblContactNum.Content = emp.Salary;
                }
                else
                    throw new Ticket_Exception("Ticket record not found");

            }
            catch (Ticket_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    }
}
